/*
Laura Smith 9/7/2022 2:13 AM toecheck.cpp 169 lines
Lab 1 CS202 Tic-Tac-Toe Part 2
For this lab I needed to create two parts, this is part two which takes in an array of any size
which is a completed game. I needed my code to first read in this array and then asses whether a
win by X or O occured or a tie. In this part of the lab I utilized cin/cout, if loops, for loops, 
while loops, nested loops, and arrays. 
*/


#include <iostream>

using namespace std;

int main (){

    //initialize values
    int size = 0;
    int row = 0;
    int col = 0;
    char val = ' ';
    

    //create the board using the input file's specified size
    cin >> size;
    char board [size][size];
    
    //put values in the board with a for loop
    for(int i = 0; i < size; i++){
        for (int j = 0; j < size; j++){
            cin >> val;
            board[i][j] = val;
        }
    }

    //WIN CHECKS

        //horizontal 'O' win check
        /*
        Checks each row looking for 'O' if it runs into anything but an O it goes onto the next
        row until the end of the board. If it doesn't get broken out and it's at the end of the 
        row then it's a win for 'O'
        */
        for (row = 0; row <= size; row++){
            for (col = 0; col <= size; col++){ 
                if (board[row][col] != 'O'){ 
                 break;
                }
                else if (col == (size-1)){ 
                    cout << "O wins" << endl;  
                    return 0; 
                }
              
            } 
        }

        //horizontal 'X' win check
        //works same as horizontal 'O' check but checks for X's
        for (row = 0; row <= size; row++){
            for (col = 0; col <= size; col++){ 
                if (board[row][col] != 'X'){ 
                 break;
                }
                else if (col == (size-1)){ 
                    cout << "X wins" << endl;   
                    return 0; 
                }
              
            } 
        }

        //vertical 'O' win check
        //works same as horizontal 'O' check but checks the columns instead of the rows
        for (col = 0; col <= size; col++){
            for (row = 0; row <= size; row++){ 
                if (board[row][col] != 'O'){ 
                    break;
                }
                else if (row == (size-1)){ 
                    cout << "O wins" << endl;  
                    return 0;    
                }
            }  
        }

        //vertical 'X' win check
        //works the same as vertical 'O' check but checks for 'X' 
        for (col = 0; col <= size; col++){
            for (row = 0; row <= size; row++){ 
                if (board[row][col] != 'X'){ 
                    break;
                }
                else if (row == (size-1)){ 
                    cout << "X wins" << endl;  
                    return 0;    
                }
            }  
        }

        //Left diagonal 'O' win check
        /*
        starts in the top left and adds to the row and column each time to check along the main 
        diagonal for 'O'. If it runs into anything that isn't an 'O' it goes to next check as 
        there is only one diagonal running this way.
        */
        row= 0;
        for (col = 0; col <= size; col++){ 
            if (board[row][col] != 'O')
                break;
            else if (col == (size-1) && row == (size-1)){
            cout << "O wins" << endl;
            return 0;
            }
            row = row + 1;
        }

        //Left diagonal 'X' win check
        //works same as left diagonal 'O' win check but looks for 'X' instead
        row= 0;
        for (col = 0; col <= size; col++){
            if (board[row][col] != 'X')
                break;
            else if (col == (size-1) && row == (size-1)){
            cout << "X wins" << endl;
            return 0;
            }
            row = row + 1;
        }

        //Right diagonal 'O' win check
        /*
        Starts in top right of grid and works it's way down to the bottom left by adding to the row
        and subtracting from the column each time. If it detects anything but an 'O' it goes to next
        win check since there is only one diagonal running this way.
        */
        row = 0;
        for (col = size-1; col <= size; col--){
            if (board[row][col] != 'O'){
                break;
            }
            
            else if (col == 0 && row == size-1){
            cout << "O wins" << endl;
            return 0;
            }
            row = row + 1;
        }

        //Right diagonal 'X' win check
        //works same as right diagonal 'O' win check but checks for 'X' instead
        row = 0;
        for (col = size-1; col <= size; col--){
            if (board[row][col] != 'X'){
                break;
            }
            
            else if (col == 0 && row == size-1){
            cout << "X wins" << endl;
            return 0;
            }
            row = row + 1;
        }
    

    //If it's none of the win conditions then it has to be a tie
    cout << "Tie" << endl; 

    return 0;
}