// Lab 7:  N-queens using backtracking 
/* Laura Smith 11:58 PM Lab 7 Part 2
In this part I added in another validity check to check the validity of the board as it is being made to decrease the time
it takes to calculate the valid boards. I also added a counter that counts the number of boards that are checked to be valid.
*/

#include <iostream>

using namespace std;

int count {}; //Global variable to keep counts of how many boards are checked

//checks if a board is valid and returns as either true or false
bool valid (int board[], int size){

//double nested for loops that iterate through each possible combination of two spots on the board
//returns false if the two spots are in the same row, or if they are on the same slope, otherwise returns true
  for (int i=0; i < size; i++){
    for (int j= i + 1; j < size; j++){
      int board_first = board[i];
      int board_second = board[j];

      if (board_first == board_second){
        return false;
      }
      else if ((abs(board_first - board_second) == abs(i-j))){
        return false;
      } 
    }
  }

  return true;
}

//recursive function that takes an array, column number, and size of the board
void nqueens (int board[], int col, int size){

//if statement to check if a board is valid before continuing
  if (valid (board, col-1)){

//prints out the board when the board is full
    if (col == size){

//counts the amount of boards considered with constraints
      count++;

        if (valid (board, size)){
          cout << board[0];
          for (int i = 1; i < size; i++){
            cout << ", " << board[i]; 
          }
          cout << endl;
        }
      }

//until the board is full runs the recursive statement to fill it
    else {
        for (int i = 0; i < size; i++){
          board[col] = i;

          nqueens (board, col+1, size);
        }
      
    }

  }

}

int main(int argc, char *argv[]) {

  int size = atoi (argv[1]);  //reads in from the command line to get the size
  int board[size];            //creates the board of the specified size
  count = 0;                  //starts count at 0 for each time

  nqueens (board, 0, size);   //begins the recursive function

  cerr << endl << "# of boards considered with constraint for n = " << size << " is " << count << endl << endl; //error statement to print out count

  return 0;

}
