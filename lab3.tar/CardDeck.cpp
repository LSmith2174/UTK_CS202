/* Laura Smith 9/21/2022 4:23 AM  CardDeck.cpp 108 lines
Lab 3 CS 202 Black Jack Part 2
The purpose of this cpp file is to take the functions initialized
in the header file and create what they do. This file makes the deck, 
initializes the constructor, destructor, and copy constructor, along with 
gets the deck size, total of the player's hands, shuffle, display, and deal.
*/


#include <algorithm>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include "CardDeck.h"

//default Constructor
CardDeck::CardDeck (int n) {
    size = n;
    deck = new int [size];

    for (int i = 0; i < n; i++)
        deck[i] = (i % 10) + 2;
}

//Copy Constructor
CardDeck::CardDeck (const CardDeck &CardDeckToCopy)  : size (CardDeckToCopy.size)  {

  deck = new int[size]; // create space for pointer-based CardDeck

  for (int i = 0; i < size; i++)
    deck[i] = CardDeckToCopy.deck[i]; // copy into object

}  // end of copy constructor

//Destructor
CardDeck::~CardDeck() {

  delete[] deck; // release pointer-based CardDeck space

} // end destructor

//Function Operator 
const CardDeck &CardDeck::operator = (const CardDeck &obj) {
    if (&obj != this){
        if (size != obj.size){
            delete[] deck;
            size = obj.size;
            deck = new int[size];
        }
        for (int i = 0; i < size; i++)
            deck[i] = obj.deck[i];
    }
    return (*this);
}

//Returns current size of the deck
int CardDeck::getSize() {
    return size;
}

//Returns the current total of player/dealer's cards
int CardDeck::getTotal(int *hand, int size){
    int total = 0;

    for (int i = 0; i < size; i++){
        total = total + hand[i];
    }

    return total;
}

//Shuffles the Deck
void CardDeck::shuffle(){
    std::random_shuffle(&deck[0], &deck[size]);
}

//Displays the first 10 cards of the deck
void CardDeck::display() {
    for (int i = 0; i < 10; i++)
        printf("%d ", deck[i]);
}

//Deals cards to player/dealer
void CardDeck::deal (int *&hand, int size){
    int *new_hand = new int [size + 1]; //create a new hand that is one larger than the current hand

    //Copies the old hand to the new hand, then in the last extra slot of new hand adds the card at the top of the deck
    for (int i = 0; i < size; i++)
        new_hand[i] = hand[i];

    new_hand[size] = deck[0];

    //Old hand is deleted so that the new hand can be assigned to the variable hand
    delete[] hand;
    hand = new_hand;

    int *new_deck = new int [this->size - size]; //create a new deck that is one smaller than the last

    // Copy the old deck starting at the second card into the newdeck, take one from deck's size
    for (int i = 1; i < this->size - size; i++)
        new_deck[i-1] = deck [i];

    this->size--;

    //Deletes the old deck so that the new deck can be assigned to the variable deck
    delete[] deck;
    deck = new_deck;
}