/* Laura Smith 9/21/2022 4:23 AM  main.cpp 173 lines
Lab 3 CS 202 Black Jack Part 3
The purpose of main is to create the deck, test the deck and shuffle then
initiate play. Play happens within the do while loop in which it deals two 
cards to both the player and dealer, with only the dealer's second card being
revealed. The player is then asked to hit or stand, hit deals another card until
they reach 21 (win or tie) or over 21 (loss), stand moves to dealer's turn. On 
dealer's turn if they're under 17 they keep drawing cards, after the reach 17 or 
above, over 21 is a loss for the dealer, and less in total than the player is also 
a loss. Game tracks score and keeps going as long as user enters y when prompted if 
they want to continue. A n ends the game and shows the final score.
*/
#include <iostream>
#include "CardDeck.h"

int main() {

    //initialize values that don't need to be reset each round, but rather every game
    char choice;
    int player_win = 0;
    int dealer_win = 0;
    int tie = 0;

    CardDeck * deck; //pointer to a single CardDeck object
    deck = new CardDeck(10);

    //displays cards before and after shuffling
    deck->display();
    deck->shuffle();
    printf("\n");
    deck->display();

    delete deck; //deletes this 'tester' deck
    printf("\n");

    //makes new deck and shuffles
    deck = new CardDeck();
    deck->shuffle();

    do{
        //initialize values that reset each round of the game
        int player_size = 0;
        int dealer_size = 0;
        int *dealer_hand = new int [0];
        int *player_hand = new int [0];

        //when the deck is less than 15 it makes a new deck and shuffles
        if (deck->getSize() < 15){
            delete deck;
            deck = new CardDeck();
            for(int i = 0; i < (rand() % 10) + 1; i++) 
                deck->shuffle();
        }

        //score tally prints out at the beginning of each round
        printf("---------------------------------\n");
        printf("player [%d] | dealer [%d] | tie [%d]\n", player_win, dealer_win, tie);
        printf("---------------------------------\n");
        
        //dealing to player and dealer and displaying it
        deck->deal (dealer_hand, dealer_size++);
        deck->deal (dealer_hand, dealer_size++);
        printf("Dealer: X, %d (%d)\n", dealer_hand[1], dealer_hand[1]);

        deck->deal (player_hand, player_size++);
        deck->deal (player_hand, player_size++);
        printf("Player: %d, %d (%d)\n", player_hand[0], player_hand[1], deck->getTotal(player_hand, player_size));

        //player's turn
        while (true){
            //Takes a choice from the player to draw or let the dealer go
            printf("Hit? (H)  or  Stand? (S) ");
            std::cin >> choice;

            //draws for each time player enters H and adds to the total of their cards unitl the reach <= 21 
            if (choice == 'H'){
               deck->deal(player_hand, player_size++);

                printf("Your Hand: ");
                for (int i = 0; i < player_size; i++)
                    printf("%d ", player_hand[i]);
                printf("(%d)\n", deck->getTotal(player_hand, player_size));

                //if player reaches over 21 they lose and goes to next round
                if (deck->getTotal(player_hand, player_size) > 21){
                    printf("Player Busted! Dealer wins!\n");
                    dealer_win++;
                    break;
                }
                //if they reach 21 it goes to dealer's turn
                else if (deck->getTotal(player_hand, player_size) == 21){
                    printf("Congrats, you reached 21, dealer's turn\n");
                    choice = 'S';
                }
            }

            if (choice == 'S'){

                //Dealer's turn
                //Dealer draws while their total is under 17
                while (deck->getTotal(dealer_hand, dealer_size) < 17){
                    deck->deal (dealer_hand, dealer_size++);
                }   
                
                //They bust when their total goes above 21
                if (deck->getTotal(dealer_hand, dealer_size) > 21){
                    //this prints the dealers final hand, same for each round end condition
                    printf("Dealer: ");
                    for (int i = 0; i < dealer_size; i++)
                        printf("%d ", dealer_hand[i]);
                    printf("(%d)\n", deck->getTotal(dealer_hand, dealer_size));

                    printf("Dealer Busted! Player wins!\n");
                    player_win++;
                    break;
                }
                //If the Dealer has a higher total than they win
                else if (deck->getTotal(dealer_hand, dealer_size) > deck->getTotal(player_hand, player_size)){
                    printf("Dealer: ");
                    for (int i = 0; i < dealer_size; i++)
                        printf("%d ", dealer_hand[i]);
                    printf("(%d)\n", deck->getTotal(dealer_hand, dealer_size));

                    printf("Dealer's Total is Greater! Dealer Wins!\n");
                    dealer_win++;
                    break;
                }
                //If player has higher total, they win
                else if (deck->getTotal(dealer_hand, dealer_size) < deck->getTotal(player_hand, player_size)){
                    printf("Dealer: ");
                    for (int i = 0; i < dealer_size; i++)
                        printf("%d ", dealer_hand[i]);
                    printf("(%d)\n", deck->getTotal(dealer_hand, dealer_size));

                    printf("Player's Total is Greater! Player Wins!\n");
                    player_win++;
                    break;
                }
                //If their totals are equal it's a tie
                else if (deck->getTotal(dealer_hand, dealer_size) == deck->getTotal(player_hand, player_size)){
                    printf("Dealer: ");
                    for (int i = 0; i < dealer_size; i++)
                        printf("%d ", dealer_hand[i]);
                    printf("(%d)\n", deck->getTotal(dealer_hand, dealer_size));

                    printf("Tie!");
                    tie++;
                    break;
            }               
                break;
            }
        }

        //delete the current hands
        delete player_hand;
        delete dealer_hand;

        //prompt user if they want to continue
        printf("do you wish to continue? (y/n) ");
        std::cin >> choice;

        if (choice == 'y') //yes goes to next round
            continue;
        else{ //no or anything else ends the game and shows the final score
            printf("FINAL SCORE:\n");
            printf("---------------------------------\n");
            printf("player [%d] | dealer [%d] | tie [%d]\n", player_win, dealer_win, tie);
            printf("---------------------------------\n");
            break;
        }
        
    } while (true); //end of do while loop

}