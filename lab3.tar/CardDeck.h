/* Laura Smith 9/21/2022 4:23 AM  CardDeck.h 36 lines
Lab 3 CS 202 Black Jack Part 1
The purpose of this header file is to initialize values for 
the deck and functions for the deck as well as the constructors 
for the rule of three. 
*/

#ifndef CardDeck_h
#define CardDeck_h

#include <iostream>

class CardDeck {

    private: 

        int *deck;  //Pointer to first element of pointer based array
        int size;   //deck size

    public:

        CardDeck(int n = 52); //Default Constructor
        CardDeck(const CardDeck &obj); //Copy Constructor
        ~CardDeck(); //Destructor

        const CardDeck &operator=(const CardDeck &obj); //assignment operator

        //function initialization
        int getSize();
        int getTotal(int *hand, int size);
        void shuffle();
        void display();
        void deal(int *&hand, int size);
};

#endif