/*
Laura Smith 9/14/2022 5:13 AM C4Board.cpp 188 lines
Lab 2 CS202 Connect 4 Part 2
For this part of the lab I used functions initialized in C4Board.h to initialize functions, 
display the board, go through play, and check for wins. Display used nested loops to go 
through each column and print out what was in them along with lines to make it easily 
readable. Play is the backbone of this project, in which it assigns players, starts the 
game and used both display and winCheck to make a game experience. CheckWin used nested
loops to go through values to check for 4 of the same value in a row. 
*/

#include "C4Board.h"
#include <iostream>

using namespace std;

C4Board::C4Board() { 

    //header file value initialization
    numCol = 7;
    minCol = 0;
    maxCol = 7;
}


void C4Board::display(){ 

    //nested for loops to go through each value in the columns and print them along with double lines on each side of the value
    for (int i = board[0].getMaxDiscs() - 1; i >= 0; i--) {
        cout << "|| ";
        for (int j = 0; j < numCol; j++)
            cout << board[j].getDisc(i) << " || ";
    
        cout << endl;
    }
}


void C4Board::play() { 

    //value initialization
    player = 'X';
    int turn = 1;
    int column = 0;
    maxCol = 7;

    //Welcome message
    cout << endl << "Ready to play Connect 4? I hope so!" << endl;

    //while loop to keep running the game while there is room on the board
    while (turn <= 42){
        //even turns is O and odd is X with turns starting on 1
        if (turn % 2 == 0)
            player = 'O';
        else 
            player = 'X';
    
    //display current board before player chooses column
    cout << endl;
    display(); 

    //Player is prompted to choose column and then that value is put into column
    cout << endl << "Player " << player << " it's your turn, choose a column: ";
    if (!(cin >> column)) //error check the input
        return;

    //while loops error check to make sure it's a valid column that is within range and isn't full
    while (column > maxCol || column < 0){
        cout << "Error out of bounds, choose again: " << endl;
        cin >> column;
    }
    while (board[column].isFull()){
        cout << "Error column full, choose again: " << endl;
        cin >> column;
    }

    //Player's disk is put into board at the specified column
    board[column].addDisc(player);

    //run check win, if no continues on, if yes ends the game and congratulates player
    if (checkWin()){
        cout << endl;
        display();
        cout << "Congrats " << player << "! You've won the game!" << endl;
        return;
    }

    //adds to the turn counter
    turn++;
    }

    //when while loop is broken, that means board is full and there was a tie. 
    display();
    cout << "It's a tie!" << endl;
    return;

}


int C4Board::checkWin() { 

    //initialize values 
    int winCountH = 0;
    int winCountV = 0;

    //Vertical check
    //use nested for loops to go up a column looking for four similar discs in a row
    for (int i = 0; i < numCol; i++){                       
        winCountV = 0;                                          //resets win counter in new column
            for (int j= 0; j < board[0].getMaxDiscs(); j++){
                if (board[i].getDisc(j) == player)
                    winCountV++;                                //adds to win counter when same disc
                else 
                    winCountV = 0;                              //resets at non player disc
                if (winCountV == 4)
                    return 1;                                   //makes check win true when win counter at 4
            }
    }

    //Horizontal check
    //use nested loops to go across the rows looking for four similar discs in a row
    for (int i = 0; i < board[0].getMaxDiscs(); i++) {
        winCountH = 0;                                          
            for (int j = 0; j < numCol; j++){
                if(board[j].getDisc(i) == player)
                    winCountH++;                                
                else 
                    winCountH = 0;                  
                if (winCountH == 4)
                    return 1;
            }
    }

 /*Diagonal Plan
    this was my first attempt at the diagonal before I got help going in another direction
    I wanted to keep this in so I could hopefully get feedback on why this method didn't work
    and to show the evolution of my process. It's very heavily commented so that you can possibly 
    understand the direction I was attempting to go in.
    I made two types of rows and columns, the rowUp and colUp were to keep track of the beggining of the diagonal
    rowAcross and colAcross were the tracking down the diagonal and testing each one 

    Starts at col 0, row 3 and goes down to the right, then next diagonal starts at col 1, row 3 and so on

    for (rowUp = 3; rowUp < 6; rowUp++){                            //moves row up after previous row is checked for diagonals
        rowAcross = rowUp;                                          //aligns start of check to start row
        winCountRD = 0;                                             //resets count
        colUp = 0;                                                  //resets the moving col 
            for (colUp = 0; colUp < 7; colUp++){                    //for loop that moves the starting col of the diagonal                                 
                winCountRD = 0;                                     //reset win count when the start column changes
                for(colAcross = colUp; colAcross < 4; colAcross++){ //for loop going one column over for every row it goes down
                    if (board[colAcross].getDisc(rowAcross) == player)//counting each time the player appears 
                        winCountRD++;
                    if (board[colAcross].getDisc(rowAcross) != player)//when other player shows up in diagonal win is reset
                        winCountRD = 0;
                    if (winCountRD == 4)                            //if the player shows up 4 times without interuption, then win
                        return 1;
                    rowAcross--;                                    //moving the row down for every column it goes over 
                }
            }
    } 
 */

    //Right Diagonal </> 
    //outer loop goes up to a new row, inner loop goes right to a new column
    for(int i = minCol; i < 3; i++){
        for (int j = 0; j < 4; j++){
            //if statement checks directly for 4 of the same in a row starting at (j, i)
            if (board[j].getDisc(i) == player && board[j+1].getDisc(i+1) && board[j+2].getDisc(i+2) == player && board[j+3].getDisc(i+3) == player){
                return 1; 
            }
        }
    }


    //Left Diagonal <\>
    //outer loop goes up to a new row, inner loop goes left to a new column
    for(int i = 3; i < 6; i++){
        for (int j = 0; j < 4; j++){
            //if statement checks directly for 4 of the same in a row starting at (j, i)
            if (board[j].getDisc(i) == player && board[j+1].getDisc(i-1) && board[j+2].getDisc(i-2) == player && board[j+3].getDisc(i-3) == player){
                return 1; 
            }
        }
    }

    //return false if no win detected
    return 0; 
}