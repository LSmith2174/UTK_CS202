/*
Laura Smith 9/14/2022 5:13 AM main.cpp  20 lines
Lab 2 CS202 Connect 4 Part 3
For this lab I needed to create five files, two header and 3 cpp files. The first header file
"C4Col.h" created a class in which listed the variables and functions used to create each column 
which each acted as their own array of 'discs'. This header file was used in C4Col.cpp to create functions 
to access, change, and get information on each column. The next header file was "C4Board.h" 
which created variables and functions that were used to control the board and initiate play. "C4Board.cpp" 
is where the bulk of the code was, and was used to display the board to the user, initiate play and keep 
it goingconditionally, and to check for wins. "Main.cpp" then uses the four other files together to finish
up the game. 

Credit: karim chmayssani for idea on how to succesfully make diagonal win check
        TA Blake for building blocks of h files and cpp files as shown in lap 2 video and ppt
        TA Drew and Margaret Kelley for general help with debugging

*/

#include "C4Board.h"   // class definition for C4Board used below


int main() {
  C4Board c4;   // instantiate an instance of a C4Board object
  c4.play();        // play game!!
}
