/*
Laura Smith 9/14/2022 5:13 AM C4Board.h 25 lines
Lab 2 CS202 Connect 4 Part 2
This header file was created to create a class to acces the 
varius columns and create the board along with initializing
the function which are the backbone of the game
*/

#include <iostream>
#include "C4Col.h"

class C4Board {
    
    private:
        int numCol;
        int maxCol;
        int minCol;
        char player;
        C4Col board[7];
    public:
        C4Board();
        void display();
        void play();
        int checkWin();
};