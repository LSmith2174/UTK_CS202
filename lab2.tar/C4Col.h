/*
Laura Smith 9/14/2022 5:13 AM C4Col.h 23 lines
Lab 2 CS202 Connect 4 Part 1
This header file was created to create the column class of
the game, creating the variables needed and the functions 
needed for the columns to operate correctly during the game. 
*/

#include <iostream>

class C4Col {
    private:
        int numDiscs;
        int maxDiscs;
        char discs[6];

    public:
        C4Col();
        int isFull();
        char getDisc (int);
        int getMaxDiscs ();
        void addDisc (char);
};