/*
Laura Smith 9/14/2022 5:13 AM C4Col.cpp 65 lines
Lab 2 CS202 Connect 4 Part 1
This cpp file was created to create the columns and the functions
associated with them. This file created isFull which detected when 
a column was full, getDisc which returned the disc at a given point 
in the column specified, getMaxDisc which returns the max number of 
discs allowed in a column, and addDisc which added in a char representing
each player into the column during each turn. 
*/

#include "C4Col.h"

using namespace std;

C4Col::C4Col(){

    //initialize values
    numDiscs = 0;
    maxDiscs = 6;

    //for loop to initialized columns to - to represent free spaces
    for (int i = 0; i < maxDiscs; i++){
        discs[i] = '-';
    }
}

int C4Col::isFull(){

    //if the number of discs in column is the max number of discs returns true, otherwise false
    if (numDiscs == maxDiscs)
        return 1;
    else 
        return 0;
}

char C4Col::getDisc(int j){

    //if input is in bounds returns the char of the specified disc otherwise tells player that it's out of bounds
    if(j >= 0 && j < 6)
        return discs[j];
    else {
        cout << "Out of Bounds" << endl;
        return 0;
    }
    
}

int C4Col::getMaxDiscs(){
    
    //just returns max number of discs
    return maxDiscs;
}

void C4Col::addDisc(char newDisc){

        //if the input is a valid player representation, then it adds it to the column, if not tells player that it's an invalid disc
        if (newDisc == 'X' || newDisc == 'O')
            discs[numDiscs++] = newDisc;
        else {
            cout << "Invalid Disc" << endl;
            return;
        }

}