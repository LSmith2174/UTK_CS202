// Lab 6: Is it prime?
/* Laura Smith 10/18/22 9:30 pm Primes Lab part 1
This part of the lab lists out primes in lines of 20 up to the inputed
max value. I used booleans and loops to do this and learned more about
both. This was the beginning of the lab and was the first step to later
solving other parts. 
*/

#include <iostream>

using namespace std;

int main() {

  int max;              //max
  bool is_prime = true; //bool for prime/notprime
  cin >> max;           //only takes in one max
  int num = 2;
  int count = 0;        //to count how many are printed per line

  while (num <= max){
    if (num != 0 && num != 1){
        for (int i = 2; i <= num/2; i++){ //goes through num/2 to test if it's prime or not
            if (num % i == 0){
                is_prime = false;
                break;
            }
            is_prime = true;
        }
    }

        if (is_prime){ //only prints out the primes
        cout << num << ", ";
        count ++;
            if (count % 20 == 0){ // to keep it at 20 per line
                cout << endl;
            }
        }

            
    num++; //iteration
  }
  
  return 0;

}