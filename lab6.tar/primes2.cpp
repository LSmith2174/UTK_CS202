// Lab 6: Is it prime?
/* Laura Smith 10/18/22 9:30 pm Primes Lab part 2
This part of the lab stores the primes in a vector and then uses find to
determine if the number is prime based on if it was added to the vector or not.
This part of the lab taught me to use vector iterators and the stl function
find as well as improving my vector abilities. 
*/

#include <iostream>
#include <vector>         //vectors duh
#include <bits/stdc++.h>  //for the iteration and find
#include <cmath>          //used sqrt

using namespace std;

int main(int argc, char *argv[]) {

  int max = 0;                //user's inputted max
  bool is_prime = true;       //bool of is or isn't prime
  vector <int> primes;      
  vector <int>::iterator it;  //vector and iterator for primes
  int num = 2;

  int oldMax = max;           //initializing max and old max to 0

  while (cin >> max){
  
    if (oldMax < max){ //only runs if there's more to add
    
      while (num <= max){
        if (num != 0 && num != 1){// to start at 2 to save time
            for (int i = 2; i <= sqrt(num); i++){//goes through sqrt num to check if it's prime
                if (num % i == 0){
                    is_prime = false;
                    break;
                }
                is_prime = true;
            }
        }

            if (is_prime){//when it's prime it's added to the vector with pushback
            // add to vector 
              primes.push_back(num);
            }

                
        num++; //iterate the number
      }
    }
    oldMax = max; //to keep track of what the old max is


    //find function which uses and iterator to look for the max
    it = find (primes.begin(), primes.end(), max);
    if (it != primes.end())
      cout << "prime" << endl;
    else
      cout << "not prime" << endl;
  }
  

  return 0;

}

