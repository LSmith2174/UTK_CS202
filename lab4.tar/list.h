/* Laura Smith 9/28/2022  1:09 AM  list.h 40 lines
Lab 4 CS 202 Adding List-Based Intergers 
This header file initilizes things for the node and list classes.
Node class just worries about the nodes or the chains of the linked
lists, each chain has a number and a pointer to the next chain.
List initialized functions used to make the linked lists and then add
them together later.
*/

#include <iostream>
#include <string>
#include <cstdio>

//start of Node class
class Node {
	public:			//public functions to make the nodes
		Node(int);	//function to make the node which takes an int
		int data;	//number of the node
		Node *next;	//pointer to next node
};
//end of Node class

//start of List class
class List {

	private:				
		Node *head;			//private pointer to the head
		Node *newNode(int);	//private function to only use in list.cpp to make a new node
        int count;			//used in getCount

	public:					//public function initilizations
		List();				//constructor
		~List();			//deconstructor
		void addNode(int);	
		int empty();		
		int getCount();		
		Node *getHead();	
		void print();
};
//end of List class