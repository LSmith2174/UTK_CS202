/* Laura Smith 9/28/2022  1:09 AM  main.cpp 133 lines
Lab 4 CS 202 Adding List-Based Intergers 
First is the sumList function which actually adds together the lists, while
in main the lists are created and then sumList is called for them. I learned
how to use node pointers and the other syntax related to linked lists.
*/

#include "list.h"
#include <cstdio>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

//helper function to add contents of list
List *sumLists(List *list1, List *list2) {
   
    int carry = 0;  //The carried value, should always be 1 or 0
    int value = 0;  //The value getting put into the answer linked list
    
    List *list3 = new List; //answer linked list

    //pointers to the head of both numbers
    Node *node1 = list1->getHead();
    Node *node2 = list2->getHead();
    
    //if either of the lists are empty, just return the other list
    if (list1->empty()){
        return list2;
    }
    else if (list2->empty()){
        return list1;
    }

    //while loop which goes through until both numbers are at the end
    while (node1 != NULL || node2 != NULL){

        //these keep track of the current value of each list
        int val1 = 0;
        int val2 = 0;

        //both of these if/else statements check if it's at the end
        //when at the end it sets the current value of the list at 0
        //if it has a value, it sets the current value to it and then goes to the next node in the list
        if (node1 == NULL)
            val1 = 0;
        else{
            val1 = node1->data;
            node1 = node1->next;
        }

        if (node2 == NULL)
            val2 = 0;
        else {
            val2 = node2->data;
            node2 = node2->next;
        }

        //this caculates the value that goes into the answer list
        //carried value, and the data from the same point in the lists are added
        value = carry + val1 + val2;

        //if the value is over 9 then 1 will have to be carried and value is only the remainder
        //if not over nine the carry value is set back to 0
        if (value > 9){
            carry = 1;
            value = value % 10;
        }
        else 
            carry = 0;

        //finally adds the final value to the answer list
        list3->addNode(value);
    }

    //if carry is over 0 after both lists are at the end, it adds one to the end of the answer linked list
    if (carry > 0)
        list3->addNode(carry);

    //returns the answer linked list
    return list3;
}

int main(int argc, char *argv[]) {
    
    string Digits;  //string of the inputed line of numbers

    while (getline(cin, Digits)){   //while loop goes as long as there is input
        
        //puts the numbers into digits
        istringstream sin(Digits);

        //puts each number into it's own string
        string num1;
        sin >>  num1;

        string num2;
        sin >> num2;

        //list pointers to make linked lists for both numbers and the answer list
        List *list1 = new List;
        List *list2 = new List;
        List *list3;

        //these keep track of the length of each number
        int size1 = num1.size();
        int size2 = num2.size();

        //for loops to go through each number string to put it into a linked list backwards
        for (int i = 1; i <= size1; i++){
            int digit = (int)num1[size1 - i];   //starts at the last number and goes to the first
            list1->addNode(digit - 48);         //-48 to translate from ASCII to int
        }

        for (int i = 1; i <= size2; i++){
                int digit = (int)num2[size2 - i];
                list2->addNode(digit - 48);
            }
        
        //puts the answer list into list3 and then prints it
        list3 = sumLists(list1, list2);
        list3->print();
        cout << endl;

        //these delete anything new was called on, which are the three linked lists
        delete list1;
        delete list2;
        delete list3;
    }

	return 0;
}