/* Laura Smith 9/28/2022  1:09 AM  list.cpp 105 lines
Lab 4 CS 202 Adding List-Based Intergers 
This creates the functions that were initialized in the header file. The node
function just creates the nodes of the linked list which each node has data and 
a pointer to the next node. For list there is a constructor and deconstructor along 
with functions to help in main. It initiates the functions newNode, addNode, empty, 
getCount, getHead, and print. In print I also learned how to use strings and push_back better.
*/

#include "list.h"
#include <string>
#include <sstream>

using namespace std;

//start of Node functions
Node::Node(int i) {
	data = i;
	next = NULL;
}
//end of Node functions

//start of List functions
List::List() {
	head = NULL;
	count = 0;
}

//copied Dr. Emrich's function
List::~List() {
	if (!empty()) { 				// follow the links, clobbering as we go
		Node *p = head;

		while (p != NULL) {
			Node *next = p->next; 	// retrieve this node's "next" before we clobber it
			delete p;
			p = next;
		}
	}
}

//helper function to create a new node
Node *List::newNode(int i) {
	Node *node = new Node(i);
	node->next = NULL;
	return node;
}

//copied Dr. Emrich's function 
void List::addNode(int i) {
    Node *node; 				//creates a node pointer to the linked list

        if (head == NULL){  	//if this is a new list and it is empty, calls newNode
            head = newNode(i);
        }
        else { 					//otherwise it adds the inputed value into the next node on the list
            for(node=head; node->next != NULL; node = node->next);
            node->next = newNode(i);
        }
}

//function to check if a list is empty
int List::empty() {
	if (head != NULL) 	//if it has stuff in it
        return(false);
    else              	//if it doesn't have stuff in it
        return(true);
}

int List::getCount() {
	Node *node;			//make a pointer to the head node
    int count = 0;		//int to keep track of the count

    for (node = head; node->next != NULL; node = node->next) 
        count++;		//for loop goes through each node and just adds to count for each node
    
    return (count);
}

//returns pointer to the first node/ the head
Node *List::getHead() {
	return (head);
}

//function to print out the linked lists in the correct order
void List::print() {
	if (!empty()) { 
			
		string numPrint;			//string of the numbers to use later

		if (!empty()){
			Node *node = head;		//pointer to the head of the linked list
			while(node != NULL){	//until the list reaches the end, it pushes the list's data into the string
				numPrint.push_back(node->data + '0');
				node = node->next;
			}
			for (int i = numPrint.size()-1; i>=0; i--){
				cout << numPrint[i]; //for loop to go through the string to print it out to the screen
			}
		}
	}
	else
		printf("empty\n"); 			//if the linked list is empty it returns as empty
}
//end of List functions